shell-tools
===========

Shell tools for mostly Linux use - some of them are POSIX compliant and work on OSX too
